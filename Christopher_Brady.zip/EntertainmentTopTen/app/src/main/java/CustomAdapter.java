

public class CustomAdapter {
}
