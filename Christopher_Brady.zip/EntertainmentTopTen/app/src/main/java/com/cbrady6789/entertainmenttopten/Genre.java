package com.cbrady6789.entertainmenttopten;

public class Genre {
    String _id;
    String GenreName;

    public Genre(){   }

    public Genre(String GenreId, String GenreName){
        this._id = GenreId;
        this.GenreName = GenreName;


    }

    //getters and setters
    public String getGenreId() {
        return _id;
    }

    public void setGenreId(String genreId) {
        _id = genreId;
    }

    public String getGenreName() {
        return GenreName;
    }

    public void setGenreName(String genreName) {
        GenreName = genreName;
    }
}
