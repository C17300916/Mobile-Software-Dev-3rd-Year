package com.cbrady6789.entertainmenttopten;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class SearchResults extends ListActivity {
    ArrayList<Movie> searchResultsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);
        DatabaseHandler db = new DatabaseHandler(this);

        searchResultsList = new ArrayList<Movie>();

        //getting each string entered from search
        String movieName = getIntent().getStringExtra("movieName");
        String directorName = getIntent().getStringExtra("directorName");
        String actorName = getIntent().getStringExtra("actorName");

        //setting cursors for each query
        Cursor cursor1 = db.findMovieName(movieName);
        Cursor cursor2 = db.findMovieDirector(directorName);
        Cursor cursor3 = db.findMovieActor(actorName);


        //adding movie name query results to search resultsList
        if (cursor1.moveToFirst()) {
            do {
                Movie movie = new Movie();
                movie.setMovieName(cursor1.getString(0));
                movie.setRating(cursor1.getString(1));

                searchResultsList.add(movie);
            } while (cursor1.moveToNext());
        }

        //adding director name query results to search resultsList
        if (cursor2.moveToFirst()) {
            do {
                Movie movie = new Movie();
                movie.setMovieName(cursor2.getString(0));
                movie.setRating(cursor2.getString(1));

                searchResultsList.add(movie);

            } while (cursor2.moveToNext());
        }

        //adding actor name query results to search resultsList
        if (cursor3.moveToFirst()) {
            do {
                Movie movie = new Movie();
                movie.setMovieName(cursor3.getString(0));
                movie.setRating(cursor3.getString(1));

                searchResultsList.add(movie);
            } while (cursor3.moveToNext());
        }

        //checking if there was no results found and setting text
        if(searchResultsList.size() < 1){
            TextView t = findViewById(R.id.welcomeText);
            t.setText("No Results Found");
        }

        //setting list adapter for movie name and rating
        setListAdapter(new SearchResults.CustomAdapter(SearchResults.this, R.id.moviename,searchResultsList));
        setListAdapter(new SearchResults.CustomAdapter(SearchResults.this, R.id.movierating,searchResultsList));

    }

    public class CustomAdapter extends ArrayAdapter<Movie> {
        private ArrayList<Movie> dataSet;
        Context mContext;


        public CustomAdapter(Context context, int rowLayoutId, ArrayList<Movie> data)
        {
            super(context, rowLayoutId, data);
            dataSet = data;
            this.mContext = context;
        }


        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View row=inflater.inflate(R.layout.resultrow, parent, false);

            //setting movie name text
            TextView movName = row.findViewById(R.id.moviename);
            movName.setText(dataSet.get(position).getMovieName());

            //setting movie rating text
            TextView movRating = row.findViewById(R.id.movierating);
            movRating.setText(dataSet.get(position).getRating());

            return row;
        }
    }

    //onclick for list
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        TextView t = v.findViewById(R.id.moviename);
        String selection = t.getText().toString();

        //calling movie details and passing moviename
        Intent intent = new Intent(this, MovieDetails.class);
        intent.putExtra("movie",selection );

        startActivity(intent);


    }



}

