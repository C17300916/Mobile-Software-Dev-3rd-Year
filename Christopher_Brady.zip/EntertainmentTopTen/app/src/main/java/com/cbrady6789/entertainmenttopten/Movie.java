package com.cbrady6789.entertainmenttopten;

public class Movie {
    String _id;
    String MovieName;
    String Plot; // Movie Plot
    String LeadActors; // Actors
    String Rating; // Rating
    String Director; // Director
    String Genre; // Genre ID


    public Movie(){   }

    public Movie(String MovieId, String MovieName, String Plot, String LeadActors, String Rating, String Director, String Genre){
        this._id = MovieId;
        this.MovieName = MovieName;
        this.Plot= Plot;
        this.LeadActors= LeadActors;
        this.Rating= Rating;
        this.Director= Director;
        this.Genre= Genre;


    }

    //Getters and Setters

    public String getMovieId() {
        return _id;
    }

    public void setMovieId(String movieId) {
        _id = movieId;
    }

    public String getMovieName() {
        return MovieName;
    }

    public void setMovieName(String movieName) {
        MovieName = movieName;
    }

    public String getPlot() {
        return Plot;
    }

    public void setPlot(String plot) {
        Plot = plot;
    }

    public String getLeadActors() {
        return LeadActors;
    }

    public void setLeadActors(String leadActors) {
        LeadActors = leadActors;
    }

    public String getRating() {
        return Rating;
    }

    public void setRating(String rating) {
        Rating = rating;
    }

    public String getDirector() {
        return Director;
    }

    public void setDirector(String director) {
        Director = director;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        Genre = genre;
    }



}
