package com.cbrady6789.entertainmenttopten;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MovieDetails extends AppCompatActivity {


    String movie_id ="";

    ArrayList<String> favList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        DatabaseHandler db = new DatabaseHandler(this);

        //getting moviename that was passed
        String movieName = getIntent().getStringExtra("movie");

        //setting the movie name
        TextView t = findViewById(R.id.viewMName);
        t.setText(movieName);


        Cursor cursor= db.getSpecGenre(movieName);
        //setting textview values
        TextView genreName = findViewById(R.id.genreName);
        TextView plot = findViewById(R.id.PlotText);
        TextView actors = findViewById(R.id.LeadActorsName);
        TextView rating = findViewById(R.id.RatingName);
        TextView director = findViewById(R.id.DirectorName);


        //passing through query result and setting texts
        if (cursor.moveToFirst()) {
            do {
                genreName.setText(cursor.getString(0));
                director.setText(cursor.getString(1));
                actors.setText(cursor.getString(2));
                rating.setText(cursor.getString(3));
                plot.setText(cursor.getString(4));
                movie_id = cursor.getString(5);

            } while (cursor.moveToNext());
        }

        //Reference: This Gesture Detector code is based from what i found @ https://stackoverflow.com/questions/4804798/doubletap-in-android
        findViewById(R.id.DTap).setOnTouchListener(new View.OnTouchListener() {
            private GestureDetector gestureDetector = new GestureDetector(MovieDetails.this, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    DatabaseHandler db = new DatabaseHandler(MovieDetails.this);

                    String changed = "";

                    ImageView star = findViewById(R.id.imageView);

                    //checking if the movie is in Favourites table and setting Star based on this
                    if(inFavs(movie_id)){
                        db.delFav(movie_id);
                        changed = "Removed";
                        star.setImageResource(R.drawable.not_fav);
                    }
                    else{
                        db.addFavourite(new FavouriteTable(movie_id));
                        changed = "Added";
                        star.setImageResource(R.drawable.is_fav);

                    }


                    String mName = "";
                    Cursor cursor = db.getName(movie_id);

                    //using cursor to get movie name
                    if (cursor.moveToFirst()) {
                        do {
                            mName = cursor.getString(0);

                        } while (cursor.moveToNext());
                    }

                    //calling toast
                    Toast toast = Toast.makeText(MovieDetails.this, changed + " " + mName , Toast.LENGTH_SHORT);
                    toast.show();

                    Log.i("counter", "text is " + movie_id);
                    return super.onDoubleTap(e);
                }
            });

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                gestureDetector.onTouchEvent(event);
                return true;
            }
        });
        //Reference : End


        //checking if the movie is in Favourites table and setting Star based on this
        ImageView star = findViewById(R.id.imageView);
        if(inFavs(movie_id)){
            star.setImageResource(R.drawable.is_fav);
        }
        else{
            star.setImageResource(R.drawable.not_fav);
        }
    }

    public void click(View v) {
        DatabaseHandler db = new DatabaseHandler(this);

        String Name = "";
        Cursor cursor3 = db.getName(movie_id);

        //adding option to open google search of movie name if button clicked
        if (cursor3.moveToFirst()) {
            do {
                Name = cursor3.getString(0);

            } while (cursor3.moveToNext());
        }

        //Reference: the following code was based on what i found from https://stackoverflow.com/questions/4800575/start-google-search-query-from-activity-android
        try {
            String escapedQuery = URLEncoder.encode(Name, "UTF-8");
            Uri uri = Uri.parse("http://www.google.com/#q=" + escapedQuery);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (UnsupportedEncodingException e) {
            Log.e("Yourapp", "UnsupportedEncodingException");
        }
        //Reference end


    }

    public boolean inFavs(String id){
        DatabaseHandler db = new DatabaseHandler(this);

        return  db.inFavs(id);
    }






}
