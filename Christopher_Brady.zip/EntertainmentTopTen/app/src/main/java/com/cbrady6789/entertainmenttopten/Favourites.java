package com.cbrady6789.entertainmenttopten;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
public class Favourites extends ListActivity {

    ArrayList<Movie> favList;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);
        setupBottomNavigationBar();
        setFav();

    }

    public void setFav(){

        favList = new ArrayList<Movie>();
        //accessing database
        DatabaseHandler db = new DatabaseHandler(this);

        //get all the movies in the favourites table
        Cursor cursor = db.getAllFavs();

        if (cursor.moveToFirst()) {
            do {
                Movie movie = new Movie();
                movie.setMovieName(cursor.getString(0));

                favList.add(movie);//adding movies to favourite list
            } while (cursor.moveToNext());
        }

        //setting list adapter for favourites list
        setListAdapter(new Favourites.CustomAdapter(this, R.id.moviename,favList));

        //checking if there is no favourites
        if(favList.size() < 1){
            TextView t = findViewById(R.id.welcomeText);
            t.setText("You Have No Favourites");
        }

    }



    public class CustomAdapter extends ArrayAdapter<Movie> {
        private ArrayList<Movie> dataSet;
        Context mContext;


        public CustomAdapter(Context context, int rowLayoutId, ArrayList<Movie> data)
        {
            super(context, rowLayoutId, data);
            dataSet = data;
            this.mContext = context;
        }


        public View getView(int position, View convertView, ViewGroup parent) {

            //inflating the row
            LayoutInflater inflater = getLayoutInflater();
            View row=inflater.inflate(R.layout.favs_row, parent, false);

            //setting text view to movie name
            TextView movName = row.findViewById(R.id.moviename);
            movName.setText(dataSet.get(position).getMovieName());


            return row;
        }
    }

    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        //getting the movie name
        TextView t = v.findViewById(R.id.moviename);
        String selection = t.getText().toString();

        //opening moviedetails class and passing the movie name
        Intent intent = new Intent(this, MovieDetails.class);
        intent.putExtra("movie", selection );
        startActivity(intent);


    }

    //Reference: The following code was based off example 37 at https://www.programcreek.com/java-api-examples/index.php?api=android.support.design.widget.BottomNavigationView
    private void setupBottomNavigationBar() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view);
        BottomNavigationViewMain.enableNavigation(this, bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(3);
        menuItem.setChecked(true);
    }
    //Reference: Complete

    //opening main if back pressed
    public void onBackPressed() {
        Intent intent1 = new Intent(this, MainActivity.class);
        intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        this.startActivity(intent1);
    }
}
