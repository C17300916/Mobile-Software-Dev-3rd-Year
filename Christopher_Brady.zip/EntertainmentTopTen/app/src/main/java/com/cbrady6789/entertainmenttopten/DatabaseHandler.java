package com.cbrady6789.entertainmenttopten;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;


public class DatabaseHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "MovieDB";
    //favourites table
    private static final String TABLE_FAVOURITES = "favourites";
    private static final String KEY_FAV_ID = "id_fav";
    //genre table
    private static final String TABLE_GENRE = "genre";
    private static final String KEY_GENRE_ID = "id";
    private static final String KEY_GENRE_NAME = "genre_name";
    //movies table
    private static final String TABLE_MOVIES = "movies";
    private static final String KEY_MOVIE_ID = "id_movie";
    private static final String KEY_MOVIE_NAME = "movie_name";
    private static final String KEY_PLOT = "plot";
    private static final String KEY_RATING = "rating";
    private static final String KEY_DIRECTOR = "director";
    private static final String KEY_LEAD_ACTORS = "lead_actors";



    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //3rd argument to be passed is CursorFactory instance
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_FAVOURITES_TABLE = " CREATE TABLE IF NOT EXISTS " + TABLE_FAVOURITES + "(" +
                KEY_FAV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT ," + KEY_MOVIE_ID + " INTEGER ," +
                " FOREIGN KEY (" + KEY_MOVIE_ID + ") REFERENCES " + TABLE_MOVIES + "(" + KEY_MOVIE_ID + ") )";

        String CREATE_GENRE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_GENRE + "(" +
                KEY_GENRE_ID + " INTEGER PRIMARY KEY," + KEY_GENRE_NAME + " TEXT " + ")";

        String CREATE_MOVIES_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_MOVIES + "("
                + KEY_MOVIE_ID + " INTEGER PRIMARY KEY," + KEY_MOVIE_NAME + " TEXT," + KEY_PLOT + " TEXT," +
                KEY_LEAD_ACTORS + " TEXT, " + KEY_RATING + " FLOAT, " + KEY_DIRECTOR + " TEXT," + KEY_GENRE_ID + " INTEGER ,"
                +" FOREIGN KEY (" + KEY_GENRE_ID + ") REFERENCES " + TABLE_GENRE + "(" + KEY_GENRE_ID + ")" + ")";


        db.execSQL(CREATE_GENRE_TABLE);
        db.execSQL(CREATE_MOVIES_TABLE);
        db.execSQL(CREATE_FAVOURITES_TABLE);
    }

    // update database structure
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOVIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAVOURITES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GENRE);

        // Create tables again
        onCreate(db);
    }

    // add the new movie
    void addMovie(Movie movie) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_MOVIE_ID, movie.getMovieId());
        values.put(KEY_MOVIE_NAME, movie.getMovieName()); // Movie Name
        values.put(KEY_PLOT, movie.getPlot()); // Movie Plot
        values.put(KEY_LEAD_ACTORS, movie.getLeadActors()); // Actors
        values.put(KEY_RATING, movie.getRating()); // Rating
        values.put(KEY_DIRECTOR, movie.getDirector()); // Director
        values.put(KEY_GENRE_ID, movie.getGenre()); // Genre ID

        // Inserting Row
        db.insert(TABLE_MOVIES, null, values);
        //2nd argument is String containing nullColumnHack
        db.close(); // Closing database connection
    }

    //add new Genre
    void addGenre(Genre genre) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_GENRE_ID, genre.getGenreId()); // Genre ID
        values.put(KEY_GENRE_NAME, genre.getGenreName()); // Favourites ID

        // Inserting Row
        db.insert(TABLE_GENRE, null, values);
        //2nd argument is String containing nullColumnHack
        db.close(); // Closing database connection
    }

    //add Favourite
    void addFavourite(FavouriteTable favouritetable) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_MOVIE_ID, favouritetable.getMovieId()); // Movie ID

        // Inserting Row
        db.insert(TABLE_FAVOURITES, null, values);
        //2nd argument is String containing nullColumnHack
        db.close(); // Closing database connection
    }

    void delFav(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_FAVOURITES, KEY_MOVIE_ID + "=" + id, null);

    }

    public Cursor getName(String id){
        String getname = " SELECT " + KEY_MOVIE_NAME + " FROM " + TABLE_MOVIES + " WHERE " + KEY_MOVIE_ID + " = " + id ;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor taskList = db.rawQuery(getname, null);

        return taskList;
    }

    // code to get all movies in a list view
    public Cursor getAllMovies() {
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_MOVIES;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor taskList = db.rawQuery(selectQuery, null);

        return taskList;
    }

    public Cursor getTopTen() {
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_MOVIES + " ORDER BY " + KEY_RATING + " DESC ";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor taskList = db.rawQuery(selectQuery, null);

        return taskList;
    }

    public Cursor getTopTenByG(String genre) {
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_MOVIES  + " JOIN " + TABLE_GENRE + " using ( " + KEY_GENRE_ID +  ") WHERE " + KEY_GENRE_NAME + " LIKE '" + genre + "' ORDER BY " + KEY_RATING + " DESC ";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor taskList = db.rawQuery(selectQuery, null);

        return taskList;
    }


    public Cursor getAllGenres() {
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_GENRE;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor genreList = db.rawQuery(selectQuery, null);

        return genreList;
    }

    public Cursor getAllFavs() {
        // Select All Query
        String selectQuery = " SELECT "+ KEY_MOVIE_NAME +" FROM " + TABLE_FAVOURITES + " JOIN " + TABLE_MOVIES + " using (" + KEY_MOVIE_ID + ") ";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor genreList = db.rawQuery(selectQuery, null);

        return genreList;
    }

    public boolean inFavs(String id){
        String selectQuery = " SELECT * FROM " + TABLE_FAVOURITES + " WHERE " + KEY_MOVIE_ID + " LIKE '" +  id + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor favs = db.rawQuery(selectQuery, null);

        //checking if there are results
        if(favs != null && favs.getCount() > 0){
            return true;
        }
        else{
            return false;
        }

    }


    public Cursor getSpecGenre(String movie){
        String selectQuery = " SELECT " + KEY_GENRE_NAME + "," + KEY_DIRECTOR + "," + KEY_LEAD_ACTORS + ","  + KEY_RATING + "," + KEY_PLOT + "," + KEY_MOVIE_ID + " FROM " + TABLE_MOVIES + " JOIN " + TABLE_GENRE + " using ( " + KEY_GENRE_ID + " ) WHERE "
        + KEY_MOVIE_NAME + " LIKE '" + movie + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor movDetails = db.rawQuery(selectQuery, null);

        return movDetails;
    }

    public Cursor findMovieName(String movie){
        String selectQuery = " SELECT " + KEY_MOVIE_NAME + "," +  KEY_RATING + " FROM " + TABLE_MOVIES + " WHERE "
                + KEY_MOVIE_NAME + " LIKE '%" + movie + "%'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor movDetails = db.rawQuery(selectQuery, null);

        return movDetails;
    }

    public Cursor findMovieDirector(String director){
        String selectQuery = " SELECT " + KEY_MOVIE_NAME + "," +  KEY_RATING + " FROM " + TABLE_MOVIES + " WHERE "
                + KEY_DIRECTOR + " LIKE '%" + director + "%'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor movDetails = db.rawQuery(selectQuery, null);

        return movDetails;
    }

    public Cursor findMovieActor(String actor){
        String selectQuery = " SELECT " + KEY_MOVIE_NAME + "," +  KEY_RATING + " FROM " + TABLE_MOVIES + " WHERE "
                + KEY_LEAD_ACTORS + " LIKE '%" + actor + "%'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor movDetails = db.rawQuery(selectQuery, null);

        return movDetails;
    }





}