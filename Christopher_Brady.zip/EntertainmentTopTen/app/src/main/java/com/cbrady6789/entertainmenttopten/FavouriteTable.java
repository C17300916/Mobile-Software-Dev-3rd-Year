package com.cbrady6789.entertainmenttopten;

public class FavouriteTable {
    String MovieId;

    public FavouriteTable(){   }

    public FavouriteTable(String MovieId){

        this.MovieId = MovieId;
    }

    //Getters and Setters

    public String getMovieId() {
        return MovieId;
    }

    public void setMovieId(String movieId) {
        MovieId = movieId;
    }
}
