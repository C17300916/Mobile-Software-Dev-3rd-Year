package com.cbrady6789.entertainmenttopten;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupBottomNavigationBar();

        //opening database handler
        DatabaseHandler db = new DatabaseHandler(this);


        //Initializing Database
        //genres
        db.addGenre(new Genre("1","Horror"));
        db.addGenre(new Genre("2","Comedy"));
        db.addGenre(new Genre("3","Romance"));
        db.addGenre(new Genre("4","Science Fiction"));
        db.addGenre(new Genre("5","Action"));
        db.addGenre(new Genre("6","Animation"));
        db.addGenre(new Genre("7","Western"));
        db.addGenre(new Genre("8","Drama"));



//MAIN TOP 10
        db.addMovie(new Movie("1","The Shawshank Redemption",
                "Two imprisoned men bond over a number of years, finding redemption in acts of kindness.",
                "Tim Robbins, Morgan Freeman","9.3","Frank Darabont", "8"));
        db.addMovie(new Movie("2","The Godfather",
                "The leader of an organised crime dynasty transfers control of his empire to his reluctant son.",
                "Al Pacino, Marlon Brando","9.2","Francis Ford Coppola", "8"));
        db.addMovie(new Movie("3","The Godfather: Part II",
                "The early life and career of Vito Corleone in 1920s New York City is portrayed, while his son, Michael, expands and tightens his grip on the family crime syndicate.",
                "Al Pacino, Robert De Niro","9.0","Francis Ford Coppola", "8"));
        db.addMovie(new Movie("4","The Dark Knight",
                "When menace known as The Joker wreaks havoc on the people of Gotham, Batman must fight injustice.",
                "Christian Bale, Heath Ledger","9.0","Christopher Nolan", "5"));
        db.addMovie(new Movie("5","12 Angry Men",
                "A jury holdout attempts to prevent a miscarriage of justice by forcing his colleagues to reconsider the evidence.",
                "Henry Fonda, Lee J. Cobb","8.9","Sidney Lumet", "8"));
        db.addMovie(new Movie("6","Schindlers List",
                "In Poland, during WWII, Oskar Schindler becomes concerned for his Jewish workforce after seeing persecution from the Nazis.",
                "Liam Neeson, Ralph Fiennes","8.9","Steven Spielberg", "8"));
        db.addMovie(new Movie("7","The Lord of the Rings: The Return of the King",
                "Gandalf and Aragorn lead the world of men against Saurons army, as Frodo edges closer to Mount Doom with the One Ring.",
                "Elijah Wood, Viggo Mortensen","8.9","Peter Jackson", "4"));
        db.addMovie(new Movie("8","Pulp Fiction",
                "The lives of two mob hitmen ,a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.",
                "John Travolta, Samuel L. Jackson","8.9","Quentin Tarantino", "8"));
        db.addMovie(new Movie("9","The Good, the Bad and the Ugly",
                "A bounty hunting scam joins two men in an uneasy alliance against a third in a race to find gold buried in a remote cemetery.",
                "Clint Eastwood, Eli Wallach","8.8","Sergio Lione", "7"));
        db.addMovie(new Movie("10","Fight Club",
                "An insomniac office worker and a soapmaker form an underground fight club that evolves into something much more.",
                "Brad Pitt, Edward Norton","8.8","David Fincher", "8"));

//TOP DRAMA
        db.addMovie(new Movie("11","Forrest Gump",
                "The presidencies of Kennedy and Johnson, the events of Vietnam, Watergate, and other history unfold through the perspective of an Alabama man with an IQ of 75.",
                "Tom Hanks, Robin Wright","8.8","Robert Zemeckis", "8"));
        db.addMovie(new Movie("12","Joker",
                "In Gotham City, mentally troubled comedian Arthur Fleck is disregarded and mistreated by society. He then embarks on a downward spiral of revolution and bloody crime. This path brings him face-to-face with his alter-ego: the Joker.",
                "Joaquin Phoenix, Robert De Niro","8.7","Todd Phillips", "8"));
        db.addMovie(new Movie("13","The Lord of the Rings: The Two Towers",
                "While Frodo and Sam edge closer to Mordor with the help of the shifty Gollum, the divided fellowship makes a stand against Saurons new ally, Saruman, and his hordes of Isengard.",
                "Elijah Wood, Viggo Mortensen","8.7","Peter Jackson", "8"));

//TOP HORROR
        db.addMovie(new Movie("14","Psycho",
                "A Phoenix secretary embezzles forty thousand dollars from her employers client, goes on the run, and checks into a remote motel run by a young man under the domination of his mother.",
                "Anthony Perkins, Janet Leigh","8.5","Alfred Hitchcock", "1"));
        db.addMovie(new Movie("15","The Shining",
                "A family heads to an isolated hotel for the winter where a sinister presence influences the father into violence, while his psychic son sees horrific forebodings from both past and future.",
                "Jack Nicholson, Shelley Duvall","8.4","Stanley Kubrick", "1"));
        db.addMovie(new Movie("16","Alien",
                "After a space merchant vessel perceives an unknown transmission as a distress call, its landing on the source moon finds one of the crew attacked by a mysterious lifeform, and they soon realize that its life cycle has merely begun.",
                "Sigourney Weaver, Tom Skerritt","8.4","Ridley Scott", "1"));
        db.addMovie(new Movie("17","The Exorcist",
                "When a teenage girl is possessed by a mysterious entity, her mother seeks the help of two priests to save her daughter.",
                "Ellen Burstyn, Max von Sydow","8.0","William Friedkin", "1"));
        db.addMovie(new Movie("18","Shaun Of The Dead",
                "A mans uneventful life is disrupted by the zombie apocalypse.",
                "Simon Pegg, Nick Frost","7.9","Edgar Wright", "1"));
        db.addMovie(new Movie("19","Dawn of the Dead",
                "Following an ever-growing epidemic of zombies that have risen from the dead, two Philadelphia S.W.A.T. team members, a traffic reporter, and his television executive girlfriend seek refuge in a secluded shopping mall.",
                "Anthony Perkins, Janet Leigh","7.9","George A. Romero", "1"));
        db.addMovie(new Movie("20","Night of the Living Dead",
                "A ragtag group of Pennsylvanians barricade themselves in an old farmhouse to remain safe from a bloodthirsty, flesh-eating breed of monsters who are ravaging the East Coast of the United States.",
                "Duane Jones, Judith ODea","7.9","George A. Romero", "1"));
        db.addMovie(new Movie("21","Halloween",
                "Fifteen years after murdering his sister on Halloween night 1963, Michael Myers escapes from a mental hospital and returns to the small town of Haddonfield, Illinois to kill again.",
                "Donald Pleasence","8.5","Jamie Lee Curtis", "1"));
        db.addMovie(new Movie("22","Get Out",
                "A young African-American visits his white girlfriends parents for the weekend, where his simmering uneasiness about their reception of him eventually reaches a boiling point.",
                "Daniel Kaluuya","7.7","Jordan Peele", "1"));
        db.addMovie(new Movie("23","Evil Dead II",
                "The lone survivor of an onslaught of flesh-possessing spirits holes up in a cabin with a group of strangers while the demons continue their attack.",
                "Bruce Campbell, Sarah Berry","8.5","Sam Raimi", "1"));

//TOP COMEDY
        db.addMovie(new Movie("24","Life is Beautiful",
                "When an open-minded Jewish librarian and his son become victims of the Holocaust, he uses a perfect mixture of will, humor, and imagination to protect his son from the dangers around their camp.",
                "Roberto Benigni, Nicoletta","8.6","Alfred Hitchcock", "2"));
        db.addMovie(new Movie("25","3 Idiots",
                "Two friends are searching for their long lost companion. They revisit their college days and recall the memories of their friend who inspired them to think differently, even as the rest of the world called them idiots.",
                "Aamir Khan, Madhavan","8.4","Rajkumar Hirani", "2"));
        db.addMovie(new Movie("26","OMG: Oh My God!",
                "A shopkeeper takes God to court when his shop is destroyed by an earthquake.",
                "Anthony Perkins, Janet Leigh","8.2","Umesh Shukla", "2"));
        db.addMovie(new Movie("27","Green Book",
                "A working-class Italian-American bouncer becomes the driver of an African-American classical pianist on a tour of venues through the 1960s American South.",
                "Viggo Mortensen, Mahershala Ali","8.2","Peter Farrelly", "2"));
        db.addMovie(new Movie("28","Three Billboards Outside Ebbing, Missouri",
                "A mother personally challenges the local authorities to solve her daughters murder when they fail to catch the culprit.",
                "Frances McDormand, Woody Harrelson","8.2","Martin McDonagh", "2"));
        db.addMovie(new Movie("29","Monty Python and the Holy Grail",
                "King Arthur and his Knights of the Round Table embark on a surreal, low-budget search for the Holy Grail, encountering many, very silly obstacles.",
                "Graham Chapman, John Cleese","8.2","Terry Gilliam", "2"));
        db.addMovie(new Movie("30","The Grand Budapest Hotel",
                "The adventures of Gustave H, a legendary concierge at a famous hotel from the fictional Republic of Zubrowka between the first and second World Wars, and Zero Moustafa, the lobby boy who becomes his most trusted friend.",
                "Ralph Fiennes, F. Murray Abraham","8.1","Wes Anderson", "2"));
        db.addMovie(new Movie("31","The Big Lebowski",
                "Jeff The Dude Lebowski, mistaken for a millionaire of the same name, seeks restitution for his ruined rug and enlists his bowling buddies to help get it.",
                "Jeff Bridges, John Goodman","8.1","Joel Coen", "2"));
        db.addMovie(new Movie("32","Monty Pythons Life of Brian",
                "Born on the original Christmas in the stable next door to Jesus, Brian of Nazareth spends his life being mistaken for a messiah.",
                "Graham Chapman, John Cleese","8.1","Terry Jones", "2"));
        db.addMovie(new Movie("33","Sing Street",
                "A boy growing up in Dublin during the 1980s escapes his strained family life by starting a band to impress the mysterious girl he likes.",
                "Ferdia Walsh-Peelo, Aidan Gillen","8.0","John Carney", "2"));

//TOP ROMANCE
        db.addMovie(new Movie("34","Casablanca",
                "A cynical American expatriate struggles to decide whether or not he should help his former lover and her fugitive husband escape French Morocco.",
                "Humphrey Bogart, Ingrid Bergman","8.5","Michael Curtiz", "3"));
        db.addMovie(new Movie("35","Good Will Hunting",
                "Will Hunting, a janitor at M.I.T., has a gift for mathematics, but needs help from a psychologist to find direction in his life.",
                "Robin Williams, Matt Damon","8.4","Gus Van Sant", "3"));
        db.addMovie(new Movie("36","The Secret in Their Eyes",
                "A retired legal counselor writes a novel hoping to find closure for one of his past unresolved homicide cases and for his unreciprocated love with his superior - both of which still haunt him decades later.",
                "Ricardo Darin, Soledad Villamil","8.2","Juan Jose Campanella", "3"));
        db.addMovie(new Movie("37","The Perks of Being a Wallflower",
                "An introvert freshman is taken under the wings of two seniors who welcome him to the real world.",
                "Logan Lerman, Emma Watson","8.0","Stephen Chbosky", "3"));
        db.addMovie(new Movie("38","Slumdog Millionaire",
                "A Mumbai teenager reflects on his life after being accused of cheating on the Indian version of Who Wants to be a Millionaire?",
                "Dev Patel, Freida Pinto","8.0","Danny Boyle", "3"));
        db.addMovie(new Movie("39","Groundhog Day",
                "A weatherman finds himself inexplicably living the same day over and over again.",
                "Bill Murray, Andie MacDowell","8.0","Harold Ramis", "3"));
        db.addMovie(new Movie("40","Pride and Prejudice",
                "Sparks fly when spirited Elizabeth Bennet meets single, rich, and proud Mr. Darcy. But Mr. Darcy reluctantly finds himself falling in love with a woman beneath his class. Can each overcome their own pride and prejudice?",
                "Keira Knightly, Matthew Macfadyen","7.8","Wes Anderson", "3"));
        db.addMovie(new Movie("41","Walk the Line",
                "A chronicle of country music legend Johnny Cashs life, from his early days on an Arkansas cotton farm to his rise to fame with Sun Records in Memphis, where he recorded alongside Elvis Presley, Jerry Lee Lewis, and Carl Perkins.",
                "Joaquin Phoenix, Reese Witherspoon","7.8","James Mangold", "3"));
        db.addMovie(new Movie("42","The Notebook",
                "A poor yet passionate young man falls in love with a rich young woman, giving her a sense of freedom, but they are soon separated because of their social differences.",
                "Gena Rowlands, James Garner","7.8","Nick Cassavetes", "3"));
        db.addMovie(new Movie("43","Titanic",
                "A seventeen-year-old aristocrat falls in love with a kind but poor artist aboard the luxurious, ill-fated R.M.S. Titanic.",
                "Leonardo DiCaprio, Kate Winslet","7.8","James Cameron", "3"));

//TOP SCIENCE FICTION
        db.addMovie(new Movie("44","Inception",
                "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
                "Leonardo DiCaprio, Joseph Gordon-Levitt","8.8","Christopher Nolan", "4"));
        db.addMovie(new Movie("45","The Matrix",
                "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.",
                "Keanu Reeves, Laurence Fishburne","8.7","Lana Wachowski", "4"));
        db.addMovie(new Movie("46","Star Wars: Episode V - The Empire Strikes Back",
                "After the Rebels are brutally overpowered by the Empire on the ice planet Hoth, Luke Skywalker begins Jedi training with Yoda, while his friends are pursued by Darth Vader.",
                "Mark Hamill, Harrison Ford","8.7","Irvin Kershner", "4"));
        db.addMovie(new Movie("47","Interstellar",
                "A team of explorers travel through a wormhole in space in an attempt to ensure humanitys survival.",
                "Matthew McConaughey, Anne Hathaway","8.6","Christopher Nolan", "4"));
        db.addMovie(new Movie("48","Star Wars: Episode IV - A New Hope",
                "Luke Skywalker joins forces with a Jedi Knight, a cocky pilot, a Wookiee and two droids to save the galaxy from the Empires world-destroying battle station, while also attempting to rescue Princess Leia from the mysterious Darth Vader.",
                "Mark Hamill, Harrison Ford","8.6","George Lucas", "4"));
        db.addMovie(new Movie("49","Avengers: Endgame",
                "After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos actions and restore balance to the universe.",
                "Robert Downey Jr., Chris Evans","8.5","Anthony Russo", "4"));
        db.addMovie(new Movie("50","Avengers: Infinity War",
                "The Avengers and their allies must be willing to sacrifice all in an attempt to defeat the powerful Thanos before his blitz of devastation and ruin puts an end to the universe.",
                "Robert Downey Jr., Chris Evans","8.5","Anthony Russo", "4"));
        db.addMovie(new Movie("51","Terminator 2:Judgment Day",
                "A cyborg, identical to the one who failed to kill Sarah Connor, must now protect her teenage son, John Connor, from a more advanced and powerful cyborg.",
                "Arnold Schwarzenegger, Linda Hamilton","8.5","James Cameron", "4"));
        db.addMovie(new Movie("52","Back to the Future",
                "Marty McFly, a 17-year-old high school student, is accidentally sent thirty years into the past in a time-traveling DeLorean invented by his close friend, the maverick scientist Doc Brown.",
                "Michael J. Fox, Christopher Lloyd","8.5","Robert Zemeckis", "4"));

//TOP ACTION
        db.addMovie(new Movie("53","Gladiator",
                "A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family and sent him into slavery.",
                "Russel Crowe","8.5","Ridley Scott", "5"));
        db.addMovie(new Movie("54","The Dark Knight Rises",
                "Eight years after the Jokers reign of anarchy, Batman, with the help of the enigmatic Catwoman, is forced from his exile to save Gotham City from the brutal guerrilla terrorist Bane.",
                "Christian Bale, Tom Hardy","8.4","Christopher Nolan", "5"));
        db.addMovie(new Movie("55","Raiders of the Lost Ark",
                "In 1936, archaeologist and adventurer Indiana Jones is hired by the U.S. government to find the Ark of the Covenant before Adolf Hitlers Nazis can obtain its awesome powers.",
                "Harrison Ford, Karen Allen","8.4","Steven Spielberg", "5"));
        db.addMovie(new Movie("56","Star Wars: Episode VI - Return of the Jedi",
                "After a daring mission to rescue Han Solo from Jabba the Hutt, the Rebels dispatch to Endor to destroy the second Death Star. Meanwhile, Luke struggles to help Darth Vader back from the dark side without falling into the Emperors trap.",
                "Mark Hamill, Harrison Ford","8.3","Richard Marquand", "5"));
        db.addMovie(new Movie("57","Batman Begins",
                "After training with his mentor, Batman begins his fight to free crime-ridden Gotham City from corruption.",
                "Christian Bale, Michael Caine","8.2","Christopher Nolan", "5"));
        db.addMovie(new Movie("58","Indiana Jones and the Last Crusade",
                "In 1938, after his father Professor Henry Jones, Sr. goes missing while pursuing the Holy Grail, Professor Henry Indiana Jones, Jr. finds himself up against Adolf Hitlers Nazis again to stop them from obtaining its powers.",
                "Harison Ford, Sean Connery","8.2","Steven Spielberg", "5"));
        db.addMovie(new Movie("59","Die Hard",
                "An NYPD officer tries to save his wife and several others taken hostage by German terrorists during a Christmas party at the Nakatomi Plaza in Los Angeles.",
                "","8.","", "5"));
        db.addMovie(new Movie("60","Logan",
                "In a future where mutants are nearly extinct, an elderly and weary Logan leads a quiet life. But when Laura, a mutant child pursued by scientists, comes to him for help, he must get her to safety.",
                "Hugh Jackman, Patrick Stewart","8.1","James Mangold", "5"));
        db.addMovie(new Movie("61","Mad Max: Fury Road",
                "In a post-apocalyptic wasteland, a woman rebels against a tyrannical ruler in search for her homeland with the aid of a group of female prisoners, a psychotic worshiper, and a drifter named Max.",
                "Tom Hardy, Charlize Theron","8.1","George Miller", "5"));


//TOP ANIMATION
        db.addMovie(new Movie("62","The Lion King",
                "A Lion cub crown prince is tricked by a treacherous uncle into thinking he caused his fathers death and flees into exile in despair, only to learn in adulthood his identity and his responsibilities.",
                "Matthew Broderick, Jeremy Irons","8.5","Roger Allers", "6"));
        db.addMovie(new Movie("63","Spider-Man: Into the Spider-Verse",
                "Teen Miles Morales becomes Spider-Man of his reality, crossing his path with five counterparts from other dimensions to stop a threat for all realities.",
                "Shameik Moore, Jake Johnson","8.4","Bob Persichetti", "6"));
        db.addMovie(new Movie("64","Coco",
                "Aspiring musician Miguel, confronted with his familys ancestral ban on music, enters the Land of the Dead to find his great-great-grandfather, a legendary singer.",
                "Anthony Gonzalez, Benjamin Bratt","8.4","Lee Unkrich", "6"));
        db.addMovie(new Movie("65","Wall-E",
                "In the distant future, a small waste-collecting robot inadvertently embarks on a space journey that will ultimately decide the fate of mankind.",
                "Ben Burtt, Elissa Knight","8.4","Andrew Stanton", "6"));
        db.addMovie(new Movie("66","Toy Story 3",
                "The toys are mistakenly delivered to a day-care center instead of the attic right before Andy leaves for college, and its up to Woody to convince the other toys that they werent abandoned and to return home.",
                "Tom Hanks, Tim Allen","8.3","Lee Unkrich", "6"));
        db.addMovie(new Movie("67","Toy Story",
                "A cowboy doll is profoundly threatened and jealous when a new spaceman figure supplants him as top toy in a boys room.",
                "Tom Hanks, Tim Allen","8.3","John Lasseter", "6"));
        db.addMovie(new Movie("68","Inside Out",
                "After young Riley is uprooted from her Midwest life and moved to San Francisco, her emotions - Joy, Fear, Anger, Disgust and Sadness - conflict on how best to navigate a new city, house, and school.",
                "Amy Poehler, Bill Hader","8.2","Pete Docter", "6"));
        db.addMovie(new Movie("69","Up",
                "78-year-old Carl Fredricksen travels to Paradise Falls in his house equipped with balloons, inadvertently taking a young stowaway.",
                "Edward Asner, Jordan Nagai","8.2","Pete Docter", "6"));
        db.addMovie(new Movie("70","How to Train Your Dragon",
                "A hapless young Viking who aspires to hunt dragons becomes the unlikely friend of a young dragon himself, and learns there may be more to the creatures than he assumed.",
                "Jay Baruchel, Gerard Butler","8.1","Dean DeBlois", "6"));
        db.addMovie(new Movie("71","Finding Nemo",
                "After his son is captured in the Great Barrier Reef and taken to Sydney, a timid clownfish sets out on a journey to bring him home.",
                "Ablert Brooks, Ellen DeGeneres","8.1","Andrew Stanton", "6"));


//TOP WESTERN
        db.addMovie(new Movie("72","Once Upon a Time in the West",
                "A mysterious stranger with a harmonica joins forces with a notorious desperado to protect a beautiful widow from a ruthless assassin working for the railroad.",
                "Henry Fonda, Charles Bronson","8.5","Sergio Leone", "7"));
        db.addMovie(new Movie("73","Django Unchained",
                "With the help of a German bounty hunter, a freed slave sets out to rescue his wife from a brutal Mississippi plantation owner.",
                "Jamie Foxx, Christoph Waltz","8.4","Quentin Tarantino", "7"));
        db.addMovie(new Movie("74","For a Few Dollars More",
                "Two bounty hunters with the same intentions team up to track down a Western outlaw.",
                "Clint Eastwood, Lee Van Cleef","8.3","Sergio Leone", "7"));
        db.addMovie(new Movie("75","Unforgiven",
                "Retired Old West gunslinger William Munny (Clint Eastwood) reluctantly takes on one last job, with the help of his old partner Ned Logan (Morgan Freeman) and a young man, The Schofield Kid (Jaimz Woolvett).",
                "Clint Eastwood, Gene Hackman","8.","Clint Eastwood", "7"));
        db.addMovie(new Movie("76","The Treasure of the Sierra Madre",
                "Two Americans searching for work in Mexico convince an old prospector to help them mine for gold in the Sierra Madre Mountains.",
                "Humphrey Bogart, Walter Huston","8.2","John Huston", "7"));
        db.addMovie(new Movie("77","The Man Who Shot Liberty Valance",
                "A senator, who became famous for killing a notorious outlaw, returns for the funeral of an old friend and tells the truth about his deed.",
                "James Stewart, John Wayne","8.1","John Ford", "7"));
        db.addMovie(new Movie("78","The General",
                "When Union spies steal an engineers beloved locomotive, he pursues it single-handedly and straight through enemy lines.",
                "Buster Keaton, Marion Mack","8.1","Clyde Bruckman", "7"));
        db.addMovie(new Movie("79","The Revenant",
                "A frontiersman on a fur trading expedition in the 1820s fights for survival after being mauled by a bear and left for dead by members of his own hunting team.",
                "Leonardo DiCaprio, Tom Hardy","8.0","Alejandro G. Inarritu", "7"));
        db.addMovie(new Movie("80","Dancing with Wolves",
                "Lieutenant John Dunbar, assigned to a remote western Civil War outpost, befriends wolves and Indians, making him an intolerable aberration in the military.",
                "Kevin Costner, Mary McDonnell","8.","Kevin Costner", "7"));
    }


    //checking if the imdb image is clicked
    public void click(View v) {
        Uri uri = Uri.parse("https://www.imdb.com"); // missing 'http://' will cause crashed
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    //Reference: The following code was based off example 37 at https://www.programcreek.com/java-api-examples/index.php?api=android.support.design.widget.BottomNavigationView
    private void setupBottomNavigationBar() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view);
        BottomNavigationViewMain.enableNavigation(this, bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);
    }
    //Reference: Complete







}
