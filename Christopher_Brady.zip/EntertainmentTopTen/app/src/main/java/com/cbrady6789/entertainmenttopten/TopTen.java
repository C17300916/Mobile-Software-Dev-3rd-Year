package com.cbrady6789.entertainmenttopten;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.Toast;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;


public class TopTen extends ListActivity implements AdapterView.OnItemSelectedListener {
    ArrayList<Movie> moviesList;
    List<String> genresList;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topten);
        setupBottomNavigationBar();
        DatabaseHandler db = new DatabaseHandler(this);

        // Spinner element
        final Spinner spinner = (Spinner) findViewById(R.id.spinner);
        // Spinner click listener
        spinner.setOnItemSelectedListener(this);

        Cursor cursor= db.getAllGenres();

        moviesList = new ArrayList<Movie>();
        genresList = new ArrayList<String>();

        genresList.add("All");

        //getting all the genre names and adding them to the genre list
        if (cursor.moveToFirst()) {
            do {
                Genre genre = new Genre();
                genre.setGenreId(cursor.getString(0));
                genre.setGenreName(cursor.getString(1));

                // Adding task to list
                genresList.add(genre.getGenreName());
            } while (cursor.moveToNext());
        }

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, genresList);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);




    }//end of onCreate

    //MovieList
    public void MovieList(String genrePicked){

        DatabaseHandler db = new DatabaseHandler(this);
        Cursor top10ByG= db.getTopTenByG(genrePicked);
        Cursor top10 = db.getTopTen();

        //getting normal top 10 not filtered by genre
        if(genrePicked == null || genrePicked.equals("All")) {
            // looping through all rows and adding to list
            moviesList.removeAll(moviesList);
            if (top10.moveToFirst()) {
                do {
                    Movie movie = new Movie();
                    movie.setMovieId(top10.getString(0));
                    movie.setMovieName(top10.getString(1));
                    movie.setPlot(top10.getString(2));
                    movie.setLeadActors(top10.getString(3));
                    movie.setRating(top10.getString(4));
                    movie.setDirector(top10.getString(5));
                    movie.setGenre(top10.getString(6));
                    // Adding task to list
                    moviesList.add(movie);
                } while (top10.moveToNext() && top10.getPosition() < 10);
            }
        }
        //getting top 10 filtered by genre
        else{
            moviesList.removeAll(moviesList);
            if (top10ByG.moveToFirst()) {
                do {
                    Movie movie = new Movie();
                    movie.setMovieId(top10ByG.getString(0));
                    movie.setMovieName(top10ByG.getString(1));
                    movie.setPlot(top10ByG.getString(2));
                    movie.setLeadActors(top10ByG.getString(3));
                    movie.setRating(top10ByG.getString(4));
                    movie.setDirector(top10ByG.getString(5));
                    movie.setGenre(top10ByG.getString(6));
                    // Adding task to list

                    moviesList.add(movie);
                } while (top10ByG.moveToNext() && top10.getPosition() < 10);
            }
        }


        //adapter for movies

        setListAdapter(new CustomAdapter(TopTen.this, R.id.position,moviesList));
        setListAdapter(new CustomAdapter(TopTen.this, R.id.moviename,moviesList));
        setListAdapter(new CustomAdapter(TopTen.this, R.id.movierating,moviesList));
    }

    //onclick for Movie List
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        TextView t = v.findViewById(R.id.moviename);

        //opening movie details and passing movie name
        String selection = t.getText().toString();
        Intent intent = new Intent(this, MovieDetails.class);
        intent.putExtra("movie", selection );

        startActivity(intent);


    }

    public class CustomAdapter extends ArrayAdapter<Movie> {
        private ArrayList<Movie> dataSet;
        Context mContext;


        public CustomAdapter(Context context, int rowLayoutId, ArrayList<Movie> data)
        {
            super(context, rowLayoutId, data);
            dataSet = data;
            this.mContext = context;
        }


        public View getView(int position, View convertView, ViewGroup parent) {

            //setting variable for position of movie
            int Pos = position + 1;
            LayoutInflater inflater = getLayoutInflater();
            View row=inflater.inflate(R.layout.row, parent, false);


            //setting movie position text
            TextView pos = row.findViewById(R.id.position);
            pos.setText(""+Pos);

            //setting movie name text
            TextView movName = row.findViewById(R.id.moviename);
            movName.setText(dataSet.get(position).getMovieName());

            //setting movie rating text
            TextView movRating = row.findViewById(R.id.movierating);
            movRating.setText(dataSet.get(position).getRating());

            return row;
        }
    }

    //Reference: Code based on what i found @ https://www.journaldev.com/9231/android-spinner-drop-down-list
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();
        // Showing selected spinner item
        if(!item.equals("All"))
            Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_SHORT).show();

        MovieList(item);
    }


    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }
    //Reference end


    //Reference: The following code was based off example 37 at https://www.programcreek.com/java-api-examples/index.php?api=android.support.design.widget.BottomNavigationView
    private void setupBottomNavigationBar() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view);
        BottomNavigationViewMain.enableNavigation(this, bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);
    }
    //Reference: Complete

    //opening main if back pressed
    public void onBackPressed() {
        Intent intent1 = new Intent(this, MainActivity.class);
        intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        this.startActivity(intent1);

    }



}


