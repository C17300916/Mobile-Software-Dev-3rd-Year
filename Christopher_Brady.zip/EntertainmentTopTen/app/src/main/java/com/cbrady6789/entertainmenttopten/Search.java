package com.cbrady6789.entertainmenttopten;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Search extends AppCompatActivity implements View.OnClickListener{

    private EditText movie_name;
    private EditText director_name;
    private EditText actor_name;
    String movName;
    String dirName;
    String actName;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        setupBottomNavigationBar();

        //declaring edittexts and buttons
        movie_name = (EditText) findViewById(R.id.MovieSearch);
        director_name = (EditText) findViewById(R.id.DirectorSearch);
        actor_name = (EditText) findViewById(R.id.ActorSearch);
        Button movie_button = (Button) findViewById(R.id.movieButton);
        Button director_button = (Button) findViewById(R.id.directorButton);
        Button actor_button = (Button) findViewById(R.id.actorButton);

        //setting on click listener
        movie_button.setOnClickListener(this);
        director_button.setOnClickListener(this);
        actor_button.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {

            //if movie name search clicked , search results called
            case R.id.movieButton:
                // Get the search entry from the movie edit text field.
                movName = movie_name.getText().toString();

                Intent intent1 = new Intent(this, SearchResults.class);
                intent1.putExtra("movieName",movName );

                startActivity(intent1);

                break;

            //if director name search clicked , search results called
            case R.id.directorButton:
                // Get the search entry from the director edit text field.
                dirName = director_name.getText().toString();

                Intent intent2 = new Intent(this, SearchResults.class);
                intent2.putExtra("directorName",dirName );

                startActivity(intent2);

                break;

            //if actor name search clicked , search results called
            case R.id.actorButton:
                // Get the search entry from the actor edit text field.
                actName = actor_name.getText().toString();

                Intent intent3 = new Intent(this, SearchResults.class);
                intent3.putExtra("actorName",actName );

                startActivity(intent3);

                break;

            default:
                break;
        }

    }

    //Reference: The following code was based off example 37 at https://www.programcreek.com/java-api-examples/index.php?api=android.support.design.widget.BottomNavigationView
    private void setupBottomNavigationBar() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view);
        BottomNavigationViewMain.enableNavigation(this, bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

    }
    //Reference: Complete

    //opening main activity if back button pressed
    public void onBackPressed() {
        Intent intent1 = new Intent(this, MainActivity.class);
        intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        this.startActivity(intent1);

    }
}

